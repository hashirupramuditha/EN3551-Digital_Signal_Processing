*Select your allocated sample images (3) from the excel sheet, 
and select one more (+1) image that is not in the provided samples.
Eg: You may refer the Set11 dataset: https://paperswithcode.com/dataset/set11

*Select your allocated image quality (3) from the excel sheet.